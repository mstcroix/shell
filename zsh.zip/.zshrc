### Boletomovil (c) 2024-2025 #############################################################################################
##  marco.santacruz@boletomovil.com #############################################
#
## E X P O R T  V A R I A B L E S
#
# -- L O C A L S -----------------
export SZ_DIR=~
#
# Android
export ANDROID_HOME=~/Library/Android/sdk
#
# Code
export SZ_CODE_DIR=$SZ_DIR/Code.MacPro
export SZ_CODE_GITHUB_DIR=$SZ_CODE_DIR/GitHub
#
export SZ_CODE_XXX_DIR=$SZ_CODE_DIR/xxx
#
# Code.GitHub
#
#export SZ_GITHUB_ACCESS_TOKEN=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
export SZ_GITHUB_ACCESS_TOKEN=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
export SZ_OPENAI_API_KEY=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
#https://aistudio.google.com/apikey
export SZ_GEMINI_API_KEY=AIzaSyBr5KiIABPitS9bo1giuSrxxWdwKFhgz38
export SZ_CLICKUP_TOKEN=pk_270695702_ZWE5Y1FMA4ITDS0IUSFILF40WBZCD4O5
## curl -X GET \
#  -H "Authorization: $SZ_CLICKUP_TOKEN" \
#  "https://api.clickup.com/api/v2/task/YOS-4545" \
#  | jq

export GEMINI_API_KEY=SZ_GEMINI_API_KEY

export SZ_JIRA_API_KEY_expires_on_17_7_2025=ATATT3xFfGF08A-vhBlJn2Hjnrpi2OPcUxXpCMIgeCe0TJTd1hEeH0LvrYa12Qn5pzUT8wqvAkYo0IBE2Kk_eecErbmRpXdNCdERqXIL0LwCymTHqxUMorl5ggNpt2OehS_QboVUCYnVU6SVld6OH_n5eFy4bZVe4IgVCRAgarSCGGim2tj78E0=66228E7D
export SZ_JIRA_API_KEY=ATATT3xFfGF0vGN5Bzjl05iIBgUKDtOYghKyejhFb5Lq0nUdw8BKuQr3O6JcTQIgVhbhdlaPiYpoxMZMfADpk9icDLBv5BiHKOzq25JWQgn20fatOgqA25A9F1ddl8pCEACnnGrJcYGv_7GHA7f9w9hq-iArQ9gezLPPj-NMztkUd6aGtqLksJc=908A8113
export SZ_JIRA_BASE_URL=https://boletomovil.atlassian.net

#
# Code.GitHub.Projects
#
# -- G L O B A L S ---------------
export PATH=$PATH:$SZ_DIR/
export PATH=$PATH:$SZ_DIR/bin
export PATH=$PATH:$SZ_CODE_DIR/sh
export PATH=$PATH:$SZ_CODE_DIR/py
export PATH=$PATH:$SZ_CODE_DIR/js

export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools

### aws
export AWS_PAGER=""

#
##   A  L  I  A  S  E  S
### hashes
#### @SZ_CODE_GITHUB_DIR

hash -d env=$SZ_CODE_DIR/env
hash -d py=$SZ_CODE_DIR/py

#### YOSHI:
# localhost   
# dev       
# qa        
# prod      

hash -d dev=$SZ_CODE_GITHUB_DIR/yoshi/dev
hash -d qa=$SZ_CODE_GITHUB_DIR/yoshi/qa
hash -d prod=$SZ_CODE_GITHUB_DIR/yoshi/prod

### aliases
####   Change to Directory
##### top A-Z
alias c="cd $SZ_CODE_DIR; l; pwd"
alias py="cd $SZ_CODE_DIR/py; l; pwd"
alias js="cd $SZ_CODE_DIR/js; l; pwd"

##### fuzzy cd
alias fcd='cd "$(find ~/Code.MacPro -type d | fzf)"'

#### list
alias dir='eza -al --icons --group-directories-first --git --tree --level=2'

### self
#### zshrc
alias zs="cursor ~/.zshrc"

#### TCP:port-ssh
alias port-ssh="lsof -iTCP -sTCP:LISTEN | grep ssh"

### npm (node package manager)
alias nrs="npm run start"
alias nrd="npm run deploy"

alias nprod='npm run deploy |& tee "$(date +%Y-%m-%dT%H%M%S).prod.deploy"'
alias nqa="npm run deploy:qa"
alias nci="curl -d 'Deployment finished: SUCCESS' https://ntfy.sh/yoshi-ci"
alias nqa="curl -d 'Deployment finished: SUCCESS' https://ntfy.sh/yoshi-qa"

alias nri="npm run install"

## deploy.sh
alias sds="sh deploy.sh --service"

# Fuzzy deploy function for yoshi services
yoshi-deploy() {
  local services_dir="/Users/mstcroix/Code.MacPro/GitHub/yoshi/qa/api/services"
  local deploy_script="/Users/mstcroix/Code.MacPro/GitHub/yoshi/qa/api/deploy.sh"
  
  # Check if fzf is installed
  if ! command -v fzf &> /dev/null; then
    echo "Error: fzf is not installed. Please install it first (brew install fzf)"
    return 1
  fi
  
  # Check if services directory exists
  if [[ ! -d "$services_dir" ]]; then
    echo "Error: Services directory not found: $services_dir"
    return 1
  fi
  
  # Get list of services (yml files without extension) and use fzf to select
  local service=$(ls "$services_dir"/*.yml 2>/dev/null | \
    xargs -n1 basename | \
    sed 's/\.yml$//' | \
    fzf --height=40% --reverse --prompt="Select service: " --border)
  
  # Exit if no service selected
  if [[ -z "$service" ]]; then
    echo "No service selected. Exiting."
    return 0
  fi
  
  echo "Selected service: $service"
  
  # Extract function names from the service yml file
  local service_file="$services_dir/${service}.yml"
  local functions=$(grep -E '^  [a-zA-Z0-9_-]+:$' "$service_file" | \
    sed 's/^  //' | \
    sed 's/:$//' | \
    fzf --height=40% --reverse --prompt="Select function for $service: " --border)
  
  # Exit if no function selected
  if [[ -z "$functions" ]]; then
    echo "No function selected. Exiting."
    return 0
  fi
  
  echo "Selected function: $functions"
  echo ""
  echo "Executing: sh $deploy_script --service $service --function $functions"
  echo ""
  
  # Execute the deploy command
  sh "$deploy_script" --service "$service" --function "$functions"
}

# Create short alias
alias ydf='yoshi-deploy-fuzzy'


## adb:Android Debug Bridge
alias ai="adb install"
alias air="adb install -r"
# fuzzy adb install (-r)
a-db() {
  # lista los dispositivos conectados y usa fzf para seleccionar uno
  local device=$(adb devices | grep "device$" | grep -v "List" | fzf --prompt="Select ADB device> " --height=10 --reverse | awk '{print $1}')

  # si no se selecciona nada, salir
  if [ -z "$device" ]; then
    echo "❌ No device selected."
    return 1
  fi

  # exporta la variable ADB_SERIAL para uso global
  export ANDROID_SERIAL="$device"
  echo "✅ Selected device: $ANDROID_SERIAL"

  # si se pasan argumentos, los ejecuta con ese dispositivo
  if [ $# -gt 0 ]; then
    echo "▶️ Running: adb -s $ANDROID_SERIAL $@"
    adb -s "$ANDROID_SERIAL" "$@"
  else
    echo "ℹ️ You can now run adb commands using: adb -s $ANDROID_SERIAL ..."
  fi
}
alias adb-emulator="emulator -avd test_avd_arm -netdelay none -netspeed full &"
alias adb-run-yoshi="adb shell am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n com.yoshi/.ui.SplashActivity"


###  Yoshi:Commands
alias dev="cd $SZ_CODE_GITHUB_DIR/yoshi/dev"
alias qa="cd $SZ_CODE_GITHUB_DIR/yoshi/qa"
alias prod="cd $SZ_CODE_GITHUB_DIR/yoshi/prod"
##### build
alias yoshi-api--build="cd $SZ_CODE_GITHUB_DIR/yoshi/dev/api && ./local.sh"
alias yoshi-pos--build="cd $SZ_CODE_DIR/yoshi/pos && ./gradlew assembleDebug"
###### run
alias yoshi-db--dev="ssh -v -i ~/yoshi-dev-ec2.pem -L 3306:yoshi-dev.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-3-91-11-53.compute-1.amazonaws.com"
alias yoshi-db--background="ssh -vfN -i ~/yoshi-dev-ec2.pem -L 3306:yoshi-dev.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-3-91-11-53.compute-1.amazonaws.com"


alias yoshi-db---qa="ssh -v -i ~/yoshi-qa-ec2.pem -L 3306:yoshi-qa.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-13-216-88-163.compute-1.amazonaws.com"
alias yoshi-db--prod="ssh -v -i ~/yoshi-cash-kp.pem -L 3306:yoshi-cash.cluster-cze6ue0i44uu.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-18-212-106-186.compute-1.amazonaws.com"

#alias yoshi-db-qa="ssh -v -i ~/yoshi-qa-ec2.pem -L 40000:yoshi-qa.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-13-216-88-163.compute-1.amazonaws.com"
#alias yoshi-db-qa="ssh -N -o ExitOnForwardFailure=yes -i ~/yoshi-qa-ec2.pem -L 40000:yoshi-qa.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-13-216-88-163.compute-1.amazonaws.com"
alias yoshi-db-qa="ssh -N -f -o ExitOnForwardFailure=yes -i ~/yoshi-qa-ec2.pem -L 40000:yoshi-qa.cluster-cr1yrnbyhape.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-13-216-88-163.compute-1.amazonaws.com"

#alias yoshi-db-prod="ssh -v -i ~/yoshi-cash-kp.pem -L 40001:yoshi-cash.cluster-cze6ue0i44uu.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-18-212-106-186.compute-1.amazonaws.com"
alias yoshi-db-prod="ssh -N -f -o ExitOnForwardFailure=yes -i ~/yoshi-cash-kp.pem -L 40001:yoshi-cash.cluster-cze6ue0i44uu.us-east-1.rds.amazonaws.com:3306 ec2-user@ec2-18-212-106-186.compute-1.amazonaws.com"

alias pq=$(tail -n 1 ~/yoshi-cash.md)
alias pp=$(head -n 1 ~/yoshi-cash.md)

### ——— Yoshi DB QA Compare ——— ###
yoshi-db-qa-compare--basic() {
  local timestamp=$(date +"%Y%m%d-%H%M%S")
  local pass=$(tail -n 1 ~/yoshi-cash.md)

  mysqldump \
    --routines \
    --compact \
    --skip-triggers \
    --no-create-info \
    --no-data \
    --no-create-db \
    --set-gtid-purged=OFF \
    --single-transaction \
    --skip-lock-tables \
    --no-tablespaces \
    -h 127.0.0.1 \
    -P 40000 \
    -u marco.santacruz \
    -p"$pass" \
    yoshi \
    > "sp-compare-qa-${timestamp}.sql"

  echo "Generated sp-compare-qa-${timestamp}.sql"
  ln -sf "sp-compare-qa-${timestamp}.sql" "sp-compare-qa-latest.sql"
}

yoshi-db-qa-compare() {
  local host="127.0.0.1"
  local port="40000"
  local timestamp pass outfile

  # If port is not open, start tunnel
  if ! nc -z "$host" "$port" 2>/dev/null; then
    echo "MySQL on ${host}:${port} not reachable → starting SSH tunnel (QA)..."
    # This will background itself because of -f
    yoshi-db-qa >/dev/null 2>&1

    # Wait up to 5 seconds for port to open
    for i in {1..5}; do
      sleep 1
      if nc -z "$host" "$port" 2>/dev/null; then
        echo "Tunnel established (QA)"
        break
      fi
    done

    if ! nc -z "$host" "$port" 2>/dev/null; then
      echo "❌ ERROR: Cannot connect to ${host}:${port} even after starting tunnel." >&2
      return 1
    fi
  fi

  timestamp=$(date +"%Y%m%d-%H%M%S")
  pass=$(tail -n 1 ~/yoshi-cash.md)
  outfile="sp-compare-qa-${timestamp}.sql"

  if mysqldump \
    --routines \
    --compact \
    --skip-triggers \
    --no-create-info \
    --no-data \
    --no-create-db \
    --set-gtid-purged=OFF \
    --single-transaction \
    --skip-lock-tables \
    --no-tablespaces \
    -h "$host" \
    -P "$port" \
    -u marco.santacruz \
    -p"$pass" \
    yoshi \
    > "$outfile"; then
    echo "Generated ${outfile}"
  else
    echo "❌ mysqldump failed for QA—removing partial file" >&2
    rm -f "$outfile"
    return 1
  fi
}

### ——— Yoshi DB PROD Compare ——— ###
yoshi-db-prod-compare() {
  local host="127.0.0.1"
  local port="40001"
  local timestamp pass outfile

  # 1) Check connectivity
  if ! nc -z "$host" "$port" 2>/dev/null; then
    echo "MySQL on ${host}:${port} not reachable → starting SSH tunnel (PROD)..."

    # Start SSH tunnel in background, suppress output
    yoshi-db-prod >/dev/null 2>&1 &

    # Wait up to 5 seconds for port to open
    for i in {1..5}; do
      sleep 1
      if nc -z "$host" "$port" 2>/dev/null; then
        echo "Tunnel established (PROD)"
        break
      fi
    done

    if ! nc -z "$host" "$port" 2>/dev/null; then
      echo "❌ ERROR: Cannot connect to ${host}:${port} even after starting tunnel." >&2
      return 1
    fi
  fi

  timestamp=$(date +"%Y%m%d-%H%M%S")
  pass=$(head -n 1 ~/yoshi-cash.md)
  outfile="sp-compare-prod-${timestamp}.sql"

  if mysqldump \
    --routines \
    --compact \
    --skip-triggers \
    --no-create-info \
    --no-data \
    --no-create-db \
    --set-gtid-purged=OFF \
    --single-transaction \
    --skip-lock-tables \
    --no-tablespaces \
    -h "$host" \
    -P "$port" \
    -u marco.santacruz \
    -p"$pass" \
    yoshi \
    > "$outfile"; then

    echo "Generated ${outfile}"
    ln -sf "$outfile" "sp-compare-prod-latest.sql"

  else
    echo "❌ mysqldump failed for PROD—removing partial file" >&2
    rm -f "$outfile"
  fi
}

alias yoshi-db--run="yoshi-db--dev"

alias yoshi-api-gateway--run="mitmproxy --mode reverse:http://localhost:9999 --listen-port 9000"
alias yoshi-api-lambdas--run="node --inspect=9229 node_modules/.bin/serverless offline start --reloadHandler --host 0.0.0.0 --httpPort 9999 --stage local"
alias yoshi-dashboard--run="npm run start"
alias yoshi-pos--run="emulator -avd Medium_Phone_API_26 && adb install -r app/build/outputs/apk/debug/app-debug.apk"
##### debug
alias yoshi-api-lambdas--debug="node --trace-warnings --inspect-brk=9229 node_modules/.bin/serverless offline start --reloadHandler --host 0.0.0.0 --httpPort 9999 --stage local"
alias yoshi-api-lambdas--run-debug="SLS_DEBUG=* yoshi-api-lambdas--debug"

###### log (run with logs)
alias yoshi-api-gateway--log="mitmproxy --mode reverse:http://localhost:9999 --listen-port 9000 -s ~/Code.MacPro/py/mitm-write_to_file__logger.py"
###### clean
alias yoshi-api-lambdas--clean="rm -rf .webpack"
##
alias yoshi-api-local--run="sh local.sh 2>&1"
alias yoshi-api-local--log2="yoshi-api-local--run | tee 'yoshi-api-local--run.sh.$(date +%Y%m%d-%H%M%S).log.js'"
alias yoshi-api-local--log="yoshi-api-local--run | tee 'yoshi-api-local--run.sh.$(date +%Y%m%d-%H%M%S).$(git rev-parse --abbrev-ref HEAD | sed 's/[^a-zA-Z0-9]/_/g').log.js'"

#### MySQL:
alias mysql-local-aws-rdb="/usr/local/mysql-8.2.0-macos13-arm64/bin/mysql -h 127.0.0.1 -P 5000 -u yoshiapp -p yoshi"
alias db-dev="yoshi-db--dev"
alias db-qa="yoshi-db--qa"
#### AWS:
alias credentials="cursor $SZ_DIR/.aws/credentials"
## see cred @/usr/local/bin/cred

alias mitmd="mitmdump --mode reverse:http://127.0.0.1:9000 \
  --listen-host 127.0.0.1 --listen-port 8081 \
  -w /tmp/flows.mitm \
  -s ~py/mitm_py/mitm_trace_file.py \
  --set console_eventlog_verbosity=error --set flow_detail=0"


#### Z-Shell (zsh)
## SELECT CONCAT('cate-', UUID());
# c-uuid:console:generate uuid
c-uuid() {
  local prefix="$1"
  if [[ -z "$prefix" ]]; then
    echo "Usage: c-uuid <prefix>"
    return 1
  fi

  local uuid
  if command -v uuidgen &>/dev/null; then
    uuid=$(uuidgen | tr '[:upper:]' '[:lower:]')
  elif command -v openssl &>/dev/null; then
    uuid=$(openssl rand -hex 16 | sed -E 's/(.{8})(.{4})(.{4})(.{4})(.{12})/\1-\2-\3-\4-\5/')
  else
    echo "Error: Neither uuidgen nor openssl is available on this system."
    return 1
  fi

  echo "${prefix}-${uuid}"
}

## c-cache:clean node_modules/.cache
function c-cache() {
  echo "🔍 Searching for all node_modules/.cache folders under: $(pwd)"
  local matches=$(find . -type d -path "*/node_modules/.cache")

  if [[ -z "$matches" ]]; then
    echo "✅ No .cache directories found!"
    return
  fi

  echo "🚮 Found the following .cache directories:"
  echo "$matches"
  echo
  read "confirm?❗ Delete all of these? (y/N) "
  if [[ "$confirm" =~ ^[Yy]$ ]]; then
    echo "🧹 Deleting..."
    find . -type d -path "*/node_modules/.cache" -prune -exec rm -rf '{}' +
    echo "✅ Done."
  else
    echo "❌ Cancelled. Nothing deleted."
  fi
}

## resend-mail:send email using Resend API
export ZS_RESEND_API_KEY=re_TDvNYFrz_Jtvf5wP3RNryk2owmfxfT4Hs
function resend-mail() {
  local api_key="${ZS_RESEND_API_KEY:-}"
  local from=""
  local to=""
  local subject=""
  local html=""
  local reply_to=""

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case $1 in
      --from)
        from="$2"
        shift 2
        ;;
      --to)
        to="$2"
        shift 2
        ;;
      --subject)
        subject="$2"
        shift 2
        ;;
      --html)
        html="$2"
        shift 2
        ;;
      --reply-to)
        reply_to="$2"
        shift 2
        ;;
      --api-key)
        api_key="$2"
        shift 2
        ;;
      *)
        echo "Unknown option: $1"
        echo "Usage: resend-mail --from 'Sender <sender@example.com>' --to 'recipient@example.com' --subject 'Subject' --html '<p>Content</p>' [--reply-to 'reply@example.com'] [--api-key 'key']"
        return 1
        ;;
    esac
  done

  # Validate required fields
  if [[ -z "$api_key" ]]; then
    echo "❌ Error: RESEND_API_KEY environment variable not set. Use --api-key or export RESEND_API_KEY"
    return 1
  fi

  if [[ -z "$from" ]]; then
    echo "❌ Error: --from is required"
    return 1
  fi

  if [[ -z "$to" ]]; then
    echo "❌ Error: --to is required"
    return 1
  fi

  if [[ -z "$subject" ]]; then
    echo "❌ Error: --subject is required"
    return 1
  fi

  if [[ -z "$html" ]]; then
    echo "❌ Error: --html is required"
    return 1
  fi

  # Build JSON payload using jq for proper escaping
  local json_payload
  if [[ -n "$reply_to" ]]; then
    json_payload=$(jq -nc \
      --arg from "$from" \
      --arg to "$to" \
      --arg subject "$subject" \
      --arg html "$html" \
      --arg reply_to "$reply_to" \
      '{from: $from, to: [$to], subject: $subject, html: $html, reply_to: $reply_to}')
  else
    json_payload=$(jq -nc \
      --arg from "$from" \
      --arg to "$to" \
      --arg subject "$subject" \
      --arg html "$html" \
      '{from: $from, to: [$to], subject: $subject, html: $html}')
  fi

  if [[ -z "$json_payload" ]]; then
    echo "❌ Error: Failed to build JSON payload. Is jq installed?"
    return 1
  fi

  # Send the email
  local response=$(curl -s -w "\n%{http_code}" -X POST 'https://api.resend.com/emails' \
    -H "Authorization: Bearer $api_key" \
    -H 'Content-Type: application/json' \
    -d "$json_payload")

  local http_code=$(echo "$response" | tail -n1)
  local body=$(echo "$response" | sed '$d')

  if [[ "$http_code" -eq 200 ]] || [[ "$http_code" -eq 201 ]]; then
    echo "✅ Email sent successfully!"
    echo "$body" | jq . 2>/dev/null || echo "$body"
    return 0
  else
    echo "❌ Error sending email (HTTP $http_code)"
    echo "$body" | jq . 2>/dev/null || echo "$body"
    return 1
  fi
}

##$ Fuzzy Functions First
## ff:find file
function f-f() {
  if [[ -z "$1" ]]; then
    echo "Usage: f <pattern>"
    echo "Example: f '*.http'"
    return 1
  fi

  rg --files --glob "$1" ~
}

## fedit:find file and edit
function f-edit() {
  local file=$(find . -type f | fzf)
  [ -n "$file" ] && nano "$file"
}

function f-serverless() {
  # Step 1: Select a service name using fzf + yq
  local selectedService=$(ls './services' | fzf --prompt="Select service: ")

  # Step 2: List all functions under that service
  yq ".functions | keys | .[]" main.serverless.yml | fzf --prompt="Select function: "

}

#### AWS:
# aws log tail
# usage: log sales-capture
a-log() {
# aws logs tail "/aws/lambda/$1" --format short --follow
  local log_group="/aws/lambda/$1"
  local output_dir="./logs_$1"
  local file_counter=1

  mkdir -p "$output_dir"

  aws logs tail "$log_group" --format short --follow | awk -v dir="$output_dir" -v counter="$file_counter" '
    BEGIN {
      in_request = 0;
    }

    # Match START line
    /^START RequestId:/ {
      in_request = 1;
      split($0, parts, ": ");
      request_id = parts[2];
      buffer = $0 "\n";
      next;
    }

    # Match END line
    /^END RequestId:/ {
      buffer = buffer $0 "\n";
      file_name = sprintf("%s/request_%03d_%s.log", dir, counter, request_id);
      print buffer > file_name;
      close(file_name);
      printf("Saved: %s\n", file_name) > "/dev/stderr";
      in_request = 0;
      counter += 1;
      next;
    }

    # Append other lines while in a request block
    {
      if (in_request) {
        buffer = buffer $0 "\n";
      }
    }
  '
}

# e:edit .zshrc
alias e="cursor ~/.zshrc"
# r:reset,reload .zshrc
alias r="source ~/.zshrc"

alias pass="openssl rand -base64 32"
alias h="history | grep"
alias ip="ipconfig getifaddr en0"
alias myip="curl -s https://api.ipify.org?format=json | jq -r '.ip'"

alias ns="npm start"
alias nd="npm deploy"
alias ni="npm install"

alias shl="sh local.sh"
alias slocal="serverless offline start --reloadHandler --httpPort 9000 --stage local"
alias shd="sh deploy.sh"
alias shds="sh deploy.sh --service"
alias shqa="sh deploy.sh --qa"
alias dep="sh deploy.sh |& tee '$(date +%Y-%m-%dT%H%M%S).deploy'"
alias dqa="sh deploy.sh --qa |& tee '$(date +%Y-%m-%dT%H%M%S).qa.deploy'"
alias dprod='sh deploy.sh |& tee "$(date +%Y-%m-%dT%H%M%S).prod.deploy"'

#### git:
alias gspush="git stash push -m"
alias gspop="git stash pop"
alias gfo="git fetch origin"
#git log origin/main --first-parent --merges 
##### git.tags
alias ga="git add"
alias gc="git commit -m"
alias gp="git push"

alias gt="git tag"
alias gpt="git push --tag"

alias gs="git switch"

alias gpo="git pull origin --no-rebase"

##### git.diff-tag:diff between tag and its parent
g-diff-tag() {
  if [[ -z "$1" ]]; then
    echo "Usage: g-diff-tag tag-name"
    return 1
  fi
  local tag="$1"
  git diff "${tag}^..${tag}"
}

alias gm="git merge --no-commit --no-ff"

alias grh="git reset --hard"

alias gcp="git cherry-pick"
g-tl() {
  git for-each-ref --sort=creatordate --format='%(refname:short) | %(objectname:short) | %(creatordate:short) | %(contents:subject)' refs/tags | column -t -s '|'
}

##### git.prs:list pull requests
g-prs() {
  local suffix="$1"
  local author="${2:-mstcroix}"  # Default author is 'mstcroix' if not provided
  local repo="Boletomovil-Inc/yoshi-${suffix}"

  if [[ -z "$suffix" ]]; then
    echo "Usage: prs <repo-suffix> [author]"
    return 1
  fi

  GH_PAGER= gh pr list --state open --repo "$repo" --search "author:${author}"
}

##### git.prlb:list pull requests by branch
g-prlb() {
  gh pr list --head $(git rev-parse --abbrev-ref HEAD)
}

##### git.get-commit:get commit
function g-get-commit() {
  local commit files file

  if [[ -z "$1" ]]; then
    echo "❌ Usage: restore_commit_files <commit-hash>"
    return 1
  fi

  commit="$1"
  echo "🔍 Processing commit: $commit"

  # Get changed files
  files=("${(@f)$(git diff-tree --no-commit-id --name-only -r "$commit")}")

  if [[ $#files -eq 0 ]]; then
    echo "⚠️  No files found in commit $commit"
    return 0
  fi

  echo "📂 Files modified in commit:"
  for file in "${files[@]}"; do
    echo "  - $file"
  done

  # Overwrite files
  for file in "${files[@]}"; do
    echo "⬇️  Overwriting $file"
    mkdir -p "$(dirname "$file")"
    git show "$commit:$file" > "$file"
  done

  echo "✅ All files from $commit have been restored."
}

##### AWS:serverless
#serverless
serverless-list() {
  local service="$1"
  if [[ -z "$service" ]]; then
    echo "Usage: service <service_name>"
    return 1
  fi
  rg "^  ${service}.*:|path: /${service}|handler:.*${service}" serverless.yml
}

##### npm.test:see npm test instead
t-run() {
  while true; do
    local function="$1"
    TS_NODE_COMPILER_OPTIONS='{"noUnusedLocals": false, "noUnusedParameters": false}' node -r ts-node/register test/$function/test-$function.ts
    read "answer?🔁 Run function $function again? (y/n): "
    case "$answer" in
        [Yy]*) continue ;;
        [Nn]*) echo "👋 Exiting."; break ;;
        *) echo "⚠️  Please answer y or n." ;;
    esac
  done
}
##### npm.test.step:debug serverless (sls)node api function
t-step() {
    local function="$1"
    node --inspect-brk $(which sls) invoke local --stage local --config $function--serverless.yml --function $function --path event-api-gateway--aws-postman.json
    while true; do
    echo
    echo "▶️ Running $function function..."
    node --inspect-brk $(which sls) invoke local \
        --stage local \
        --config $function--serverless.yml \
        --function $function \
        --path event-api-gateway--aws-postman.json

    echo
    read "answer?🔁 Run function $function again? (y/n): "
    case "$answer" in
        [Yy]*) continue ;;
        [Nn]*) echo "👋 Exiting."; break ;;
        *) echo "⚠️  Please answer y or n." ;;
    esac
    done
}

#### Git
export GIT_PAGER=

alias u="git pull origin"
alias ver="git describe --tags --dirty"
alias ghist="git --no-pager log --pretty=format:'%s' main..dev"
##
##### git.get:git get
# usage: get 1441-backend api qa
#        get 1265 dashboard dev
#        get 1327 db dev "feature/Y1327/client-configuration"
#        g-get 1456 db qa feature/Y1456/concession--fee-update-inheritance    #expect: new repo: db-1456-, new branch: feature/Y1456/concession--fee-update-inheritance
g-get() {
  local ticket=$1
  local repo=$2
  local origin_branch=$3
  local new_branch=$4
  local new_dir="${repo}-Y${ticket}-${origin_branch}"

  git clone "https://github.com/Boletomovil-Inc/yoshi-${repo}" "$new_dir" 
  ln -s "$new_dir" "${repo}" 
  cd "$new_dir" 
  git checkout "$origin_branch" 
  git checkout -b "$new_branch" 
  [ -f package.json ] && npm install
  echo "🔍 Verifying version..."
  ver 
  echo "🔍 Copying environment files: Type: $origin_branch"
  [ -f "$SZ_CODE_DIR/env/${origin_branch}.env" ] && cp "$SZ_CODE_DIR/env/${origin_branch}.env" .env 
  [ -f "$SZ_CODE_DIR/env/${origin_branch}.env.yml" ] && cp "$SZ_CODE_DIR/env/${origin_branch}.env.yml" serverless.env.yml 
  cd .. 
  echo "🔍 Done!"
  echo "🔍 New repo: $new_dir"
  echo "🔍 New branch: $new_branch" 
  j $ticket > "$new_dir/${ticket}.md"
  cat "$new_dir/${ticket}.md"
}

#
##  S  T  A  R  T  U  P 
# Change to default (Project) directory
#### pushd $SZ_PROJ_DIR
# List current default directory
ls -l
#
##########################################################################################################################
# If you come from bash you might have to change your $PATH.
# export PATH=$HOME/bin:$HOME/.local/bin:/usr/local/bin:$PATH

# Path to your Oh My Zsh installation.
export ZSH="$HOME/.oh-my-zsh"

# Set name of the theme to load --- if set to "random", it will
# load a random theme each time Oh My Zsh is loaded, in which case,
# to know which specific one was loaded, run: echo $RANDOM_THEME
# See https://github.com/ohmyzsh/ohmyzsh/wiki/Themes
#ZSH_THEME="robbyrussell"
#ZSH_THEME=random
ZSH_THEME="af-magic"

# Set list of themes to pick from when loading at random
# Setting this variable when ZSH_THEME=random will cause zsh to load
# a theme from this variable instead of looking in $ZSH/themes/
# If set to an empty array, this variable will have no effect.
# ZSH_THEME_RANDOM_CANDIDATES=( "robbyrussell" "agnoster" )

# Uncomment the following line to use case-sensitive completion.
# CASE_SENSITIVE="true"

# Uncomment the following line to use hyphen-insensitive completion.
# Case-sensitive completion must be off. _ and - will be interchangeable.
# HYPHEN_INSENSITIVE="true"

# Uncomment one of the following lines to change the auto-update behavior
# zstyle ':omz:update' mode disabled  # disable automatic updates
zstyle ':omz:update' mode auto      # update automatically without asking
# zstyle ':omz:update' mode reminder  # just remind me to update when it's time

# Uncomment the following line to change how often to auto-update (in days).
# zstyle ':omz:update' frequency 13

# Uncomment the following line if pasting URLs and other text is messed up.
# DISABLE_MAGIC_FUNCTIONS="true"

# Uncomment the following line to disable colors in ls.
# DISABLE_LS_COLORS="true"

# Uncomment the following line to disable auto-setting terminal title.
# DISABLE_AUTO_TITLE="true"

# Uncomment the following line to enable command auto-correction.
# ENABLE_CORRECTION="true"

# Uncomment the following line to display red dots whilst waiting for completion.
# You can also set it to another string to have that shown instead of the default red dots.
# e.g. COMPLETION_WAITING_DOTS="%F{yellow}waiting...%f"
# Caution: this setting can cause issues with multiline prompts in zsh < 5.7.1 (see #5765)
# COMPLETION_WAITING_DOTS="true"

# Uncomment the following line if you want to disable marking untracked files
# under VCS as dirty. This makes repository status check for large repositories
# much, much faster.
# DISABLE_UNTRACKED_FILES_DIRTY="true"

# Uncomment the following line if you want to change the command execution time
# stamp shown in the history command output.
# You can set one of the optional three formats:
# "mm/dd/yyyy"|"dd.mm.yyyy"|"yyyy-mm-dd"
# or set a custom format using the strftime function format specifications,
# see 'man strftime' for details.
# HIST_STAMPS="mm/dd/yyyy"

# Would you like to use another custom folder than $ZSH/custom?
# ZSH_CUSTOM=/path/to/new-custom-folder

# Which plugins would you like to load?
# Standard plugins can be found in $ZSH/plugins/
# Custom plugins may be added to $ZSH_CUSTOM/plugins/
# Example format: plugins=(rails git textmate ruby lighthouse)
# Add wisely, as too many plugins slow down shell startup.
plugins=(git)

source $ZSH/oh-my-zsh.sh

# User configuration

# export MANPATH="/usr/local/man:$MANPATH"

# You may need to manually set your language environment
# export LANG=en_US.UTF-8

# Preferred editor for local and remote sessions
# if [[ -n $SSH_CONNECTION ]]; then
#   export EDITOR='vim'
# else
#   export EDITOR='nvim'
# fi

# Compilation flags
# export ARCHFLAGS="-arch $(uname -m)"

# Set personal aliases, overriding those provided by Oh My Zsh libs,
# plugins, and themes. Aliases can be placed here, though Oh My Zsh
# users are encouraged to define aliases within a top-level file in
# the $ZSH_CUSTOM folder, with .zsh extension. Examples:
# - $ZSH_CUSTOM/aliases.zsh
# - $ZSH_CUSTOM/macos.zsh
# For a full list of active aliases, run `alias`.
#
# Example aliases
# alias zshconfig="mate ~/.zshrc"
# alias ohmyzsh="mate ~/.oh-my-zsh"

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

# Generated for envman. Do not edit.
[ -s "$HOME/.config/envman/load.sh" ] && source "$HOME/.config/envman/load.sh"

# pnpm
export PNPM_HOME="/Users/mstcroix/Library/pnpm"
case ":$PATH:" in
  *":$PNPM_HOME:"*) ;;
  *) export PATH="$PNPM_HOME:$PATH" ;;
esac
# pnpm end

# Added by Windsurf
export PATH="/Users/mstcroix/.codeium/windsurf/bin:$PATH"

#### cargo build --release
# export PATH="$PWD/target/release:$PATH"
# echo 'export PATH="$HOME/path/to/sui/target/release:$PATH"' >> ~/.zshrc
#source ~/.zshrc
export PATH="$SZ_CODE_GITHUB_DIR/sui/target/release:$PATH"
export PATH="/opt/homebrew/opt/mysql-client@8.4/bin:$PATH"
export PATH="/Users/mstcroix/Downloads/skeema_1.12.3_mac_arm64:$PATH"
# Added by dbt Fusion extension (ensure dbt binary dir on PATH)
if [[ ":$PATH:" != *":/Users/mstcroix/.local/bin:"* ]]; then
  export PATH=/Users/mstcroix/.local/bin:"$PATH"
fi
# Added by dbt Fusion extension
alias dbtf=/Users/mstcroix/.local/bin/dbt
# ============================================================================
# GHQ + FZF + ZSH - Convenience Snippet
# Place this at the END of your ~/.zshrc
# ============================================================================

# --- Core environment --------------------------------------------------------
export GHQ_ROOT="${GHQ_ROOT:-$HOME/ghq}"   # Base folder where ghq stores repos
[ -d "$GHQ_ROOT" ] || mkdir -p "$GHQ_ROOT"

# Add ghq bin (if installed in a non-standard path)
# export PATH="$PATH:$HOME/.local/bin"

# --- fzf integration (Homebrew) ---------------------------------------------
# Keybindings and completion (ctrl-r, ctrl-t, alt-c).
# Tries Apple Silicon path first, falls back to Intel path.
if [ -f "/opt/homebrew/opt/fzf/shell/key-bindings.zsh" ]; then
  source "/opt/homebrew/opt/fzf/shell/key-bindings.zsh"
  source "/opt/homebrew/opt/fzf/shell/completion.zsh"
elif [ -f "/usr/local/opt/fzf/shell/key-bindings.zsh" ]; then
  source "/usr/local/opt/fzf/shell/key-bindings.zsh"
  source "/usr/local/opt/fzf/shell/completion.zsh"
fi

# --- Editor command ----------------------------------------------------------
# Default to VS Code if EDITOR not set; change to your favorite editor.
if [ -z "$EDITOR" ]; then
  if command -v code >/dev/null 2>&1; then
    export EDITOR="code"
  else
    export EDITOR="vi"
  fi
fi

# --- Helper functions (prefixed) --------------------------------------------
# fxPascalCase naming as requested

fxGhqPathFor() {
  # Resolve a repo path managed by ghq
  # Usage: fxGhqPathFor owner/repo  OR  fxGhqPathFor https://github.com/owner/repo.git
  ghq list --full-path | awk -v q="$1" '
    $0 ~ q"$" { print; found=1 }
    END { if (!found) exit 1 }'
}

fxGhqCd() {
  # Fuzzy-select a repo and cd into it
  local target
  target="$(ghq list | fzf --prompt='ghq> ' --height=40%)" || return
  ghq look "$target"
}

fxGhqOpen() {
  # Open the current repo in $EDITOR (or fuzzy-select if not inside a repo)
  local repoPath
  if git rev-parse --show-toplevel >/dev/null 2>&1; then
    repoPath="$(git rev-parse --show-toplevel)"
  else
    repoPath="$(ghq list --full-path | fzf --prompt='open> ' --height=40%)" || return
  fi
  "$EDITOR" "$repoPath"
}

fxGhqGet() {
  # Clone (or reuse) a repo under GHQ_ROOT: gget owner/repo OR full URL
  if [ $# -lt 1 ]; then
    echo "Usage: gget <owner/repo|url>"
    return 1
  fi
  ghq get "$1"
}

# --- Aliases -----------------------------------------------------------------
alias rcd='fxGhqCd'     # fuzzy cd into a ghq repo
alias ropen='fxGhqOpen'   # open a repo in $EDITOR
alias rclone='fxGhqGet'     # clone into GHQ_ROOT
alias rls='ghq list'      # list managed repos

# --- GitHub CLI quality-of-life ---------------------------------------------
# Login once: gh auth login
# Open PRs list: gh pr list
# View PRs in TUI: gh pr status
# ---------------------------------------------------------------------------

[[ "$TERM_PROGRAM" == "kiro" ]] && . "$(kiro --locate-shell-integration-path zsh)"

# Added by Antigravity
export PATH="/Users/mstcroix/.antigravity/antigravity/bin:$PATH"
